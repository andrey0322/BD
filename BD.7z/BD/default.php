<?php require_once("MySiteDB.php"); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Главная страница сайта</title>
    </head>
        <body>
            <menu>
            <button type="button">Выход</button>
            <button type="button">Новая заметка</button>
            <button type="button">Отправить сообщение</button>
            <button type="button">Добавить фото</button>
            <button type="button">Статистика  </button>
            <button type="button">Администратору</button>
            <button type="button">Выход</button>
            </menu>
        <p>Рад приветствовать вас на страницах моего сайта, посвященного путешествиям. </p> 
        <?php
            $query = "SELECT * FROM notes";
            $select_note = mysqli_query($link, $query);
            while ($note = mysqli_fetch_array($select_note))
            {
                echo $note['id'], "<br>";
                ?>
                <a href="comments.php?note=<?php echo $note['id']; ?>">
                <?php echo $note ['title'], "<br>";?></a>
                 
                <?php 
                 echo $note ['created'], "<br>";
                echo $note ['article'], "<br>";
            }
                
        ?>
    <body>
</html>