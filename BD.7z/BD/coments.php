<?php
$query = "SELECT created, title, article FROM notes WHERE id = $note_id";
$query_comments = "SELECT * FROM comments WHERE art_id = $note_id";
?>